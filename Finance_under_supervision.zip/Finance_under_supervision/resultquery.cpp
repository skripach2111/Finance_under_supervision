#include "resultquery.h"
